#include <SFML/Graphics.hpp>
#include <vector>

class Bullet {
public:
    sf::Sprite sprite;
    Bullet(sf::Texture& texture, sf::Vector2f position) {
        sprite.setTexture(texture);
        sprite.setPosition(position);
    }

    void update() {
        sprite.move(0.f, -10.f);
    }
};

class Enemy {
public:
    sf::Sprite sprite;
    Enemy(sf::Texture& texture, sf::Vector2f position) {
        sprite.setTexture(texture);
        sprite.setPosition(position);
    }

    void update() {
        sprite.move(0.f, .5f);
    }
};

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 600), "Simple Space Shooter");
    
    sf::Texture playerTex, bulletTex, enemyTex, backgroundTex;
    playerTex.loadFromFile("D:/OOP Project/Space Invaders/Assets/sprite_ship_3.png");
    bulletTex.loadFromFile("D:/OOP Project/Space Invaders/Assets/blaster_player/sprite_1.png");
    enemyTex.loadFromFile("D:/OOP Project/Space Invaders/Assets/big_boss1.png");
    backgroundTex.loadFromFile("D:/OOP Project/Space Invaders/assets/sprites_background_2.png");
    sf::Sprite player(playerTex);
    player.setPosition(400.f, 500.f);

    sf::Sprite background(backgroundTex);
    
    background.scale(5.f, 4.0f);

    std::vector<Bullet> bullets;
    std::vector<Enemy> enemies;
    sf::Clock enemySpawnClock;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event))
            if (event.type == sf::Event::Closed)
                window.close();

        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
            player.move(-1.0f, 0.f);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            player.move(1.0f, 0.f);

        
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
            static sf::Clock shootClock;
            if (shootClock.getElapsedTime().asMilliseconds() > 200) {
                bullets.emplace_back(bulletTex, player.getPosition());
                shootClock.restart();
            }
        }

        
        if (enemySpawnClock.getElapsedTime().asSeconds() > 1.f) {
            float x = static_cast<float>(rand() % 750);
            enemies.emplace_back(enemyTex, sf::Vector2f(x, -50.f));
            enemySpawnClock.restart();
        }

        
        for (auto& bullet : bullets) bullet.update();

        
        for (auto& enemy : enemies) enemy.update();

        
        for (size_t i = 0; i < bullets.size(); ++i) {
            for (size_t j = 0; j < enemies.size(); ++j) {
                if (bullets[i].sprite.getGlobalBounds().intersects(enemies[j].sprite.getGlobalBounds())) {
                    bullets.erase(bullets.begin() + i);
                    enemies.erase(enemies.begin() + j);
                    i--;
                    break;
                }
            }
        }
        
        bullets.erase(std::remove_if(bullets.begin(), bullets.end(),
            [](Bullet& b) { return b.sprite.getPosition().y < 0; }), bullets.end());

        
        enemies.erase(std::remove_if(enemies.begin(), enemies.end(),
            [](Enemy& e) { return e.sprite.getPosition().y > 600; }), enemies.end());

        window.clear();
        window.draw(background);
        window.draw(player);
        for (auto& bullet : bullets) window.draw(bullet.sprite);
        for (auto& enemy : enemies) window.draw(enemy.sprite);
        window.display();
    }

}
