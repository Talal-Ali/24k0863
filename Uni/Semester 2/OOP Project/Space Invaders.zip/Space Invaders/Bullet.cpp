#include"Header.h"
#include<SFML/Graphics.hpp>
using namespace sf;
class Player {
	x(0.5f * (SCREEN_WIDTH - BASE_SIZE));
};
