#pragma once
#ifndef "_HEADER_H_"
#define "_HEADER_H_"

#include<iostram>
#include<SFML/Graphics.hpp>

using namespace std;
using namespace sf;

#endif